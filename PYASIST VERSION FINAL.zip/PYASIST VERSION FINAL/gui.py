import tkinter as tk
from tkinter import messagebox
from tkinter import PhotoImage
import database as db


db.crear_tablas()

def mostrar_menu_principal(estudiante_id):
    menu_principal = tk.Toplevel(root)
    menu_principal.title("Menú Principal")

    # Titulo y logo
    titulo_label = tk.Label(menu_principal, text="Pyasist", font=("Arial", 24, "bold"))
    titulo_label.grid(row=0, column=0, columnspan=2)
    logo = PhotoImage(file="logo.png")  
    logo_label = tk.Label(menu_principal, image=logo)
    logo_label.image = logo
    logo_label.grid(row=1, column=0, columnspan=2)

    tk.Label(menu_principal, text="Bienvenido al Sistema de Gestión de Horas Libres").grid(row=2, column=0, columnspan=2)

    tk.Button(menu_principal, text="Ver Eventos", command=lambda: ver_eventos(estudiante_id)).grid(row=3, column=0)
    tk.Button(menu_principal, text="Ver Progreso", command=lambda: ver_progreso(estudiante_id)).grid(row=3, column=1)
    tk.Button(menu_principal, text="Inscribirse a un Evento", command=lambda: inscribirse_a_evento(estudiante_id)).grid(row=4, column=0)
    tk.Button(menu_principal, text="Darse de Baja de un Evento", command=lambda: darse_de_baja_de_evento(estudiante_id)).grid(row=4, column=1)
    tk.Button(menu_principal, text="Exportar Datos", command=lambda: exportar_datos(estudiante_id)).grid(row=5, column=0)
    tk.Button(menu_principal, text="Gestionar Eventos", command=gestionar_eventos).grid(row=5, column=1)
    tk.Button(menu_principal, text="Enviar Notificaciones", command=enviar_notificaciones).grid(row=6, column=0)
    tk.Button(menu_principal, text="Ver Colaboradores", command=ver_colaboradores).grid(row=6, column=1)
    tk.Button(menu_principal, text="Salir", command=menu_principal.destroy).grid(row=7, column=0, columnspan=2)

def ver_eventos(estudiante_id):
    eventos_ventana = tk.Toplevel(root)
    eventos_ventana.title("Ver Eventos")

    eventos = db.obtener_todos_los_eventos()
    for i, evento in enumerate(eventos):
        tk.Label(eventos_ventana, text=f"{evento[1]}: {evento[2]} ({evento[3]} - {evento[4]}h)").grid(row=i, column=0)

def inscribirse_a_evento(estudiante_id):
    inscripcion_evento_ventana = tk.Toplevel(root)
    inscripcion_evento_ventana.title("Inscribirse a un Evento")

    tk.Label(inscripcion_evento_ventana, text="ID del Evento").grid(row=0, column=0)
    evento_id_entry = tk.Entry(inscripcion_evento_ventana)
    evento_id_entry.grid(row=0, column=1)

    def enviar_inscripcion():
        evento_id = int(evento_id_entry.get())
        try:
            db.registrar_evento(estudiante_id, evento_id)
            messagebox.showinfo("Registro Exitoso", "Te has inscrito al evento con éxito.")
            inscripcion_evento_ventana.destroy()
        except Exception as e:
            messagebox.showerror("Registro Fallido", str(e))

    tk.Button(inscripcion_evento_ventana, text="Enviar", command=enviar_inscripcion).grid(row=1, column=0, columnspan=2)

def darse_de_baja_de_evento(estudiante_id):
    baja_evento_ventana = tk.Toplevel(root)
    baja_evento_ventana.title("Darse de Baja de un Evento")

    tk.Label(baja_evento_ventana, text="ID del Evento").grid(row=0, column=0)
    evento_id_entry = tk.Entry(baja_evento_ventana)
    evento_id_entry.grid(row=0, column=1)

    def enviar_baja():
        evento_id = int(evento_id_entry.get())
        try:
            db.dar_de_baja_evento(estudiante_id, evento_id)
            messagebox.showinfo("Baja Exitosa", "Te has dado de baja del evento con éxito.")
            baja_evento_ventana.destroy()
        except Exception as e:
            messagebox.showerror("Baja Fallida", str(e))

    tk.Button(baja_evento_ventana, text="Enviar", command=enviar_baja).grid(row=1, column=0, columnspan=2)

def ver_progreso(estudiante_id):
    progreso_ventana = tk.Toplevel(root)
    progreso_ventana.title("Ver Progreso")

    total_horas = db.calcular_horas(estudiante_id)
    horas_por_semana = total_horas / 52
    horas_por_mes = total_horas / 12
    horas_por_semestre = total_horas / 6
    horas_restantes = max(0, 96 - total_horas)

    tk.Label(progreso_ventana, text=f"Horas Totales: {total_horas}").grid(row=0, column=0)
    tk.Label(progreso_ventana, text=f"Promedio Semanal: {horas_por_semana:.2f}").grid(row=1, column=0)
    tk.Label(progreso_ventana, text=f"Promedio Mensual: {horas_por_mes:.2f}").grid(row=2, column=0)
    tk.Label(progreso_ventana, text=f"Promedio Semestral: {horas_por_semestre:.2f}").grid(row=3, column=0)
    tk.Label(progreso_ventana, text=f"Horas Restantes: {horas_restantes}").grid(row=4, column=0)

def exportar_datos(estudiante_id):
    try:
        db.exportar_datos_estudiante(estudiante_id)
        messagebox.showinfo("Exportación Exitosa", "Los datos se han exportado con éxito.")
    except Exception as e:
        messagebox.showerror("Exportación Fallida", str(e))

def gestionar_eventos():
    gestionar_ventana = tk.Toplevel(root)
    gestionar_ventana.title("Gestionar Eventos")

    tk.Label(gestionar_ventana, text="Nombre del Evento").grid(row=0, column=0)
    nombre_evento_entry = tk.Entry(gestionar_ventana)
    nombre_evento_entry.grid(row=0, column=1)

    tk.Label(gestionar_ventana, text="Descripción del Evento").grid(row=1, column=0)
    descripcion_evento_entry = tk.Entry(gestionar_ventana)
    descripcion_evento_entry.grid(row=1, column=1)

    tk.Label(gestionar_ventana, text="Fecha del Evento (AAAA-MM-DD)").grid(row=2, column=0)
    fecha_evento_entry = tk.Entry(gestionar_ventana)
    fecha_evento_entry.grid(row=2, column=1)

    tk.Label(gestionar_ventana, text="Duración del Evento (horas)").grid(row=3, column=0)
    duracion_evento_entry = tk.Entry(gestionar_ventana)
    duracion_evento_entry.grid(row=3, column=1)

    def agregar_evento():
        nombre = nombre_evento_entry.get()
        descripcion = descripcion_evento_entry.get()
        fecha = fecha_evento_entry.get()
        duracion = int(duracion_evento_entry.get())
        try:
            db.agregar_evento(nombre, descripcion, fecha, duracion)
            messagebox.showinfo("Evento Creado", "El evento ha sido creado con éxito.")
            gestionar_ventana.destroy()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    tk.Button(gestionar_ventana, text="Agregar Evento", command=agregar_evento).grid(row=4, column=0, columnspan=2)

def enviar_notificaciones():
    correos = db.obtener_todos_los_correos_estudiantes()
   
    messagebox.showinfo("Notificaciones Enviadas", f"Se enviaron notificaciones a: {', '.join(correos)}")

def ver_colaboradores():
    colaboradores_ventana = tk.Toplevel(root)
    colaboradores_ventana.title("Colaboradores")

    tk.Label(colaboradores_ventana, text="Deyner Esteban Ramirez - Ingeniero de Sistemas").grid(row=0, column=0)
    tk.Label(colaboradores_ventana, text="Evans Santiago Rojas - Ingeniero de Sistemas").grid(row=1, column=0)

def iniciar_sesion():
    correo = correo_entry.get()
    contraseña = contraseña_entry.get()
    estudiante = db.validar_estudiante(correo, contraseña)
    if estudiante:
        messagebox.showinfo("Inicio de Sesión Exitoso", "Has ingresado con éxito.")
        root.withdraw()
        mostrar_menu_principal(estudiante[0])
    else:
        messagebox.showerror("Inicio de Sesión Fallido", "Correo o contraseña incorrectos.")

def registrar():
    registrar_ventana = tk.Toplevel(root)
    registrar_ventana.title("Registrar Estudiante")

    tk.Label(registrar_ventana, text="Correo").grid(row=0, column=0)
    correo_entry_reg = tk.Entry(registrar_ventana)
    correo_entry_reg.grid(row=0, column=1)

    tk.Label(registrar_ventana, text="Contraseña").grid(row=1, column=0)
    contraseña_entry_reg = tk.Entry(registrar_ventana, show='*')
    contraseña_entry_reg.grid(row=1, column=1)

    tk.Label(registrar_ventana, text="Nombre").grid(row=2, column=0)
    nombre_entry_reg = tk.Entry(registrar_ventana)
    nombre_entry_reg.grid(row=2, column=1)

    def enviar_registro():
        correo = correo_entry_reg.get()
        contraseña = contraseña_entry_reg.get()
        nombre = nombre_entry_reg.get()
        try:
            db.agregar_estudiante(correo, contraseña, nombre)
            messagebox.showinfo("Registro Exitoso", "Te has registrado con éxito.")
            registrar_ventana.destroy()
        except Exception as e:
            messagebox.showerror("Registro Fallido", str(e))

    tk.Button(registrar_ventana, text="Enviar", command=enviar_registro).grid(row=3, column=0, columnspan=2)

root = tk.Tk()
root.title("Sistema de Gestión de Horas Libres UNAB")

# Titulo y logo
titulo_label = tk.Label(root, text="Pyasist", font=("Arial", 24, "bold"))
titulo_label.grid(row=0, column=0, columnspan=2)
logo = PhotoImage(file="logo.png")  
logo_label = tk.Label(root, image=logo)
logo_label.image = logo
logo_label.grid(row=1, column=0, columnspan=2)

tk.Label(root, text="Correo").grid(row=2, column=0)
correo_entry = tk.Entry(root)
correo_entry.grid(row=2, column=1)

tk.Label(root, text="Contraseña").grid(row=3, column=0)
contraseña_entry = tk.Entry(root, show='*')
contraseña_entry.grid(row=3, column=1)

tk.Button(root, text="Iniciar Sesión", command=iniciar_sesion).grid(row=4, column=0, columnspan=2)
tk.Button(root, text="Registrarse", command=registrar).grid(row=5, column=0, columnspan=2)

root.mainloop()
