import database as db

def calculate_hours(student_id):
    
    pass

def register_event(student_id, event_id):

    pass

def unregister_event(student_id, event_id):
   
    pass


