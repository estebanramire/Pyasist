def send_notification(email, message):
   
    pass

