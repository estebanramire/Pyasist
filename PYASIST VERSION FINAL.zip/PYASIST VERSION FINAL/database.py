import sqlite3
import csv

def crear_tablas():
    conn = sqlite3.connect('unab.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS estudiantes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                correo TEXT UNIQUE NOT NULL,
                contraseña TEXT NOT NULL,
                nombre TEXT NOT NULL
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS eventos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                descripcion TEXT,
                fecha TEXT NOT NULL,
                duracion INTEGER NOT NULL
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS registros (
                estudiante_id INTEGER,
                evento_id INTEGER,
                asistido INTEGER DEFAULT 0,
                FOREIGN KEY(estudiante_id) REFERENCES estudiantes(id),
                FOREIGN KEY(evento_id) REFERENCES eventos(id)
                )''')
    conn.commit()
    conn.close()

def agregar_estudiante(correo, contraseña, nombre):
    conn = sqlite3.connect('unab.db')
    c = conn.cursor()
    c.execute("INSERT INTO estudiantes (correo, contraseña, nombre) VALUES (?, ?, ?)", (correo, contraseña, nombre))
    conn.commit()
    conn.close()

def validar_estudiante(correo, contraseña):
    conn = sqlite3.connect('unab.db')
    c = conn.cursor()
    c.execute("SELECT * FROM estudiantes WHERE correo=? AND contraseña=?", (correo, contraseña))
    estudiante = c.fetchone()
    conn.close()
    return estudiante

def agregar_evento(nombre, descripcion, fecha, duracion):
    conn = sqlite3.connect('unab.db')
    c = conn.cursor()
    c.execute("INSERT INTO eventos (nombre, descripcion, fecha, duracion) VALUES (?, ?, ?, ?)", (nombre, descripcion, fecha, duracion))
    conn.commit()
    conn.close()

def obtener_todos_los_eventos():
    conn = sqlite3.connect('unab.db')
    c = conn.cursor()
    c.execute("SELECT * FROM eventos")
    eventos = c.fetchall()
    conn.close()
    return eventos

def registrar_evento(estudiante_id, evento_id):
    conn = sqlite3.connect('unab.db')
    c = conn.cursor()
    c.execute("INSERT INTO registros (estudiante_id, evento_id, asistido) VALUES (?, ?, 1)", (estudiante_id, evento_id))
    conn.commit()
    conn.close()

def dar_de_baja_evento(estudiante_id, evento_id):
    conn = sqlite3.connect('unab.db')
    c = conn.cursor()
    c.execute("DELETE FROM registros WHERE estudiante_id=? AND evento_id=?", (estudiante_id, evento_id))
    conn.commit()
    conn.close()

def calcular_horas(estudiante_id):
    conn = sqlite3.connect('unab.db')
    c = conn.cursor()
    c.execute('''SELECT SUM(eventos.duracion) 
                 FROM registros 
                 JOIN eventos ON registros.evento_id = eventos.id 
                 WHERE registros.estudiante_id = ? AND registros.asistido = 1''', (estudiante_id,))
    total_horas = c.fetchone()[0]
    conn.close()
    return total_horas if total_horas else 0

def exportar_datos_estudiante(estudiante_id):
    conn = sqlite3.connect('unab.db')
    c = conn.cursor()
    c.execute('''SELECT estudiantes.nombre, eventos.nombre, eventos.fecha, eventos.duracion 
                 FROM registros 
                 JOIN estudiantes ON registros.estudiante_id = estudiantes.id 
                 JOIN eventos ON registros.evento_id = eventos.id 
                 WHERE registros.estudiante_id = ?''', (estudiante_id,))
    filas = c.fetchall()
    conn.close()

    with open(f'estudiante_{estudiante_id}_datos.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Nombre del Estudiante", "Nombre del Evento", "Fecha del Evento", "Duración del Evento"])
        writer.writerows(filas)

def obtener_todos_los_correos_estudiantes():
    conn = sqlite3.connect('unab.db')
    c = conn.cursor()
    c.execute("SELECT correo FROM estudiantes")
    correos = [correo[0] for correo in c.fetchall()]
    conn.close()
    return correos
